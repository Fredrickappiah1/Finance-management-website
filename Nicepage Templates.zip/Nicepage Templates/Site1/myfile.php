<?php
session_start();

// Retrieve form data and store it in the session
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = $_POST["name"];
    $itemType = $_POST["select"];
    $price = $_POST["text"];
    $date = $_POST["text-1"];

    $_SESSION["form_data"][] = array(
        "name" => $name,
        "item_type" => $itemType,
        "price" => $price,
        "date" => $date
    );

    // Redirect back to the form page or to a thank you page
    header("Location: myfile.php");
    exit();
}
?>
